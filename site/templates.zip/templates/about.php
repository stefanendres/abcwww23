<?php snippet('head'); ?>
<?php snippet('header'); ?>
<main>
  <?php echo $page->about_text() ?>
</main>
<footer>
  
</footer>
<?php snippet('foot'); ?>
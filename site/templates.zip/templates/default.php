<?php snippet('head'); ?>
<header>
  <h1><?= $site_title ?></h1>
</header>
<main>

</main>
<footer>
  
</footer>
<?php snippet('foot'); ?>

  <?= js('assets/js/main.js', ['type' => 'module']) ?>
  </body>
</html>
